import{d as a}from"./index-CTg2hlbS.js";import{o,a as t}from"./indexPlugin-BqpxYC0m.js";a.declareIndexPlugin(o,t);
