import{d as a}from"./index-CS7Sr8Vz.js";import{o,a as t}from"./indexPlugin-DPm6YRtr.js";a.declareIndexPlugin(o,t);
