import{d as a}from"./index-CTg2hlbS.js";import{o,a as t}from"./indexPlugin-B2ilQjE0.js";a.declareIndexPlugin(o,t);
