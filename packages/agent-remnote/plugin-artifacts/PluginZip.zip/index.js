import{d as t}from"./index-CTg2hlbS.js";import{o,a}from"./indexPlugin-BqpxYC0m.js";t.declareIndexPlugin(o,a);
