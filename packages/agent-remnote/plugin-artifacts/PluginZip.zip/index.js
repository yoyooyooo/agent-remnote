import{d as t}from"./index-CS7Sr8Vz.js";import{o,a}from"./indexPlugin-DPm6YRtr.js";t.declareIndexPlugin(o,a);
