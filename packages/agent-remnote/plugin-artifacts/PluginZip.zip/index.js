import{d as t}from"./index-CTg2hlbS.js";import{o,a}from"./indexPlugin-B2ilQjE0.js";t.declareIndexPlugin(o,a);
